window.ScenarioBank = [
    {
        id: "escenario_1",
        area: "Industria",
        title: "Cambio de Requisitos",
        description: "Un cliente solicita un cambio que afecta la planificación y el equipo está frustrado.",
        completed: false,
        totalSteps: 2,
        story: [
            {
                id: 0, text: "A mitad de un sprint, el cliente pide un cambio grande. El equipo se queja de que su trabajo anterior será desechado. ¿Cómo respondes como líder?", options: [
                    { text: "Convocar una reunión para explicar la situación, validar la frustración del equipo y replanificar juntos.", result: 1, feedback: 'good', scores: { 'Liderazgo': 15, 'Comunicación': 10, 'Trabajo en Equipo': 5 } },
                    { text: "Decirle al equipo que 'el cliente siempre tiene la razón' y asignar las nuevas tareas inmediatamente.", result: 2, feedback: 'bad', scores: { 'Liderazgo': -10, 'Comunicación': -5, 'Trabajo en Equipo': -10 } },
                    { text: "Rechazar la petición del cliente para proteger la moral del equipo.", result: 2, feedback: 'neutral', scores: { 'Toma de Decisiones': -10, 'Liderazgo': 5 } }
                ]
            },
            {
                id: 1, text: "La reunión fue positiva. El equipo se siente escuchado y colabora en la nueva planificación. Han encontrado una forma de reusar parte del trabajo.", options: [
                    { text: "Reconocer públicamente el esfuerzo y la buena actitud del equipo.", result: 3, feedback: 'good', scores: { 'Liderazgo': 10, 'Trabajo en Equipo': 10 } },
                    { text: "Continuar con el trabajo sin más comentarios, asumiendo que es su deber.", result: 3, feedback: 'neutral', scores: { 'Liderazgo': -5 } }
                ]
            },
            {
                id: 2, text: "La moral del equipo ha caído. Hay tensión y el progreso se ha ralentizado. La relación con el cliente también se ha vuelto tensa.", options: [
                    { text: "Organizar una sesión individual con cada miembro para escuchar sus preocupaciones.", result: 1, feedback: 'good', scores: { 'Comunicación': 10, 'Liderazgo': 5 } },
                    { text: "Implementar reuniones diarias de seguimiento para presionar por resultados.", result: 3, feedback: 'bad', scores: { 'Liderazgo': -10, 'Trabajo en Equipo': -5 } }
                ]
            },
            { id: 3, text: "El sprint termina. Lograste manejar una situación difícil con éxito.", feedbackText: "¡Excelente manejo de la situación! Demostraste habilidades en múltiples áreas para lograr el mejor resultado.", options: [] }
        ]
    },
    {
        id: "escenario_2",
        area: "Transversal",
        title: "Feedback Conflictivo",
        description: "Dos compañeros tienen opiniones muy diferentes sobre tu trabajo y debes mediar.",
        completed: false,
        totalSteps: 2,
        story: [
            {
                id: 0, text: "Presentas un avance de tu proyecto. Ana dice que es 'innovador y arriesgado', mientras que Carlos afirma que es 'poco práctico y no cumple los requisitos'. ¿Cómo reaccionas?", options: [
                    { text: "Agradecer ambos puntos de vista y preguntar a Carlos qué requisitos específicos cree que no se cumplen.", result: 1, feedback: 'good', scores: { 'Comunicación': 15, 'Trabajo en Equipo': 5 } },
                    { text: "Defender tu trabajo, enfocándote en por qué la opinión de Carlos es incorrecta.", result: 2, feedback: 'bad', scores: { 'Comunicación': -10, 'Trabajo en Equipo': -5 } },
                    { text: "Ignorar a Carlos y agradecer a Ana por su apoyo.", result: 2, feedback: 'neutral', scores: { 'Trabajo en Equipo': -10 } }
                ]
            },
            {
                id: 1, text: "Carlos detalla sus puntos. Te das cuenta de que su crítica tiene una base válida en un requisito técnico que malinterpretaste. Ana sigue defendiendo la visión creativa.", options: [
                    { text: "Proponer una solución que integre la viabilidad técnica de Carlos con la visión creativa de Ana.", result: 3, feedback: 'good', scores: { 'Toma de Decisiones': 15, 'Trabajo en Equipo': 10 } },
                    { text: "Descartar tu idea original y seguir al pie de la letra lo que dice Carlos.", result: 3, feedback: 'neutral', scores: { 'Toma de Decisiones': -5 } }
                ]
            },
            {
                id: 2, text: "La discusión escala. Ahora el conflicto es personal entre tus compañeros y tú estás en medio.", options: [
                    { text: "Pedir la intervención de un líder o mediador para resolver el impasse.", result: 3, feedback: 'neutral', scores: { 'Toma de Decisiones': 5 } },
                    { text: "Intentar imponer tu visión original, ignorando las críticas.", result: 3, feedback: 'bad', scores: { 'Liderazgo': -10, 'Comunicación': -5 } }
                ]
            },
            { id: 3, text: "El conflicto se ha resuelto y el proyecto avanza con una solución robusta.", feedbackText: "Gestionaste el feedback de forma constructiva, demostrando una comunicación efectiva y promoviendo el trabajo en equipo.", options: [] }
        ]
    },
    {
        id: "escenario_3",
        area: "Comercio y Servicios",
        title: "Proveedor Inconfiable",
        description: "Un proveedor clave está fallando y retrasa el proyecto. Debes decidir cómo proceder.",
        completed: false,
        totalSteps: 2,
        story: [
            {
                id: 0, text: "El proveedor principal de una pieza esencial ha fallado en la última entrega, poniendo en riesgo el cronograma. ¿Qué haces primero?", options: [
                    { text: "Contactar al proveedor para entender la causa y obtener una nueva fecha.", result: 1, feedback: 'good', scores: { 'Comunicación': 10, 'Toma de Decisiones': 5 } },
                    { text: "Buscar un nuevo proveedor de inmediato sin hablar con el actual.", result: 2, feedback: 'bad', scores: { 'Toma de Decisiones': -10, 'Liderazgo': -5 } },
                    { text: "Informar a tu superior del problema y esperar instrucciones.", result: 2, feedback: 'neutral', scores: { 'Comunicación': 5, 'Liderazgo': -5 } }
                ]
            },
            {
                id: 1, text: "El proveedor se disculpa, explica que fue un problema puntual y asegura que las piezas llegarán en 2 días. ¿Confías en su palabra?", options: [
                    { text: "Aceptar la nueva fecha, pero investigar proveedores alternativos como plan B.", result: 3, feedback: 'good', scores: { 'Toma de Decisiones': 15, 'Liderazgo': 5 } },
                    { text: "Confiar plenamente y no tomar ninguna otra medida.", result: 3, feedback: 'neutral', scores: { 'Toma de Decisiones': -10 } }
                ]
            },
            {
                id: 2, text: "Tu decisión apresurada o tu inacción ha causado más retrasos. El equipo no sabe qué hacer.", options: [
                    { text: "Asumir la responsabilidad, comunicar un plan de acción claro y realinear al equipo.", result: 1, feedback: 'good', scores: { 'Liderazgo': 10, 'Comunicación': 5 } },
                    { text: "Culpar al proveedor original frente a tu equipo.", result: 3, feedback: 'bad', scores: { 'Liderazgo': -10, 'Trabajo en Equipo': -5 } }
                ]
            },
            { id: 3, text: "El proyecto se encarrila de nuevo, gracias a tu gestión.", feedbackText: "Manejaste la crisis con calma, comunicándote eficazmente y tomando decisiones prudentes basadas en la información disponible.", options: [] }
        ]
    },
    {
        id: "escenario_4",
        area: "Agroambiental",
        title: "Contaminación Imprevista",
        description: "Se descubre un problema ambiental crítico en el proceso de producción.",
        completed: false,
        totalSteps: 2,
        story: [
            {
                id: 0, text: "Un cliente reporta un error grave en el producto. Tras investigar, confirmas que afecta a todos los usuarios. ¿Cuál es tu prioridad?", options: [
                    { text: "Notificar a liderazgo y proponer un plan de comunicación transparente a los clientes.", result: 1, feedback: 'good', scores: { 'Comunicación': 15, 'Liderazgo': 10, 'Toma de Decisiones': 5 } },
                    { text: "Intentar arreglar el error en secreto antes de que más gente se dé cuenta.", result: 2, feedback: 'bad', scores: { 'Comunicación': -10, 'Toma de Decisiones': -10 } },
                    { text: "Pedirle al equipo técnico que trabaje en una solución antes de informar a nadie más.", result: 2, feedback: 'neutral', scores: { 'Liderazgo': -5, 'Trabajo en Equipo': 5 } }
                ]
            },
            {
                id: 1, text: "La comunicación transparente fue bien recibida, aunque algunos clientes están molestos. El equipo técnico ya tiene una solución.", options: [
                    { text: "Desplegar el parche, comunicar la solución y ofrecer una compensación.", result: 3, feedback: 'good', scores: { 'Toma de Decisiones': 10, 'Comunicación': 10 } },
                    { text: "Desplegar el parche y esperar que los clientes se den cuenta.", result: 3, feedback: 'neutral', scores: { 'Comunicación': -10 } }
                ]
            },
            {
                id: 2, text: "El secretismo empeoró las cosas. Los medios se han hecho eco del problema y la confianza del cliente se ha desplomado.", options: [
                    { text: "Emitir una disculpa pública y explicar las medidas que se están tomando.", result: 1, feedback: 'good', scores: { 'Liderazgo': 10, 'Comunicación': 15 } },
                    { text: "Publicar una declaración minimizando el problema.", result: 3, feedback: 'bad', scores: { 'Liderazgo': -15, 'Comunicación': -10 } }
                ]
            },
            { id: 3, text: "La crisis ha sido contenida.", feedbackText: "Tu rápida y transparente gestión de la crisis protegió la confianza del cliente y demostró un liderazgo responsable.", options: [] }
        ]
    },
    {
        id: "escenario_5",
        area: "Transversal",
        title: "Idea Rechazada",
        description: "Propones una idea innovadora en una reunión, pero tu jefe la descarta de inmediato.",
        completed: false,
        totalSteps: 2,
        story: [
            {
                id: 0, text: "En una reunión de equipo, presentas una idea que crees que mejorará un proceso. Tu jefe la desestima diciendo: 'No tenemos tiempo para eso ahora'.", options: [
                    { text: "Aceptar la decisión, pero pedir una reunión posterior para exponer los beneficios con datos.", result: 1, feedback: 'good', scores: { 'Comunicación': 10, 'Toma de Decisiones': 5 } },
                    { text: "Insistir en el momento, argumentando que está equivocado.", result: 2, feedback: 'bad', scores: { 'Comunicación': -10, 'Trabajo en Equipo': -5 } },
                    { text: "Quedarte en silencio y no volver a proponer la idea.", result: 2, feedback: 'neutral', scores: { 'Liderazgo': -5 } }
                ]
            },
            {
                id: 1, text: "En la reunión privada, presentas un análisis de costo-beneficio. Tu jefe, al ver los datos, reconsidera la idea y aprueba una prueba piloto.", options: [
                    { text: "Agradecer la oportunidad y liderar la prueba piloto con tu equipo.", result: 3, feedback: 'good', scores: { 'Liderazgo': 15, 'Toma de Decisiones': 10 } },
                    { text: "Decir 'te lo dije' de forma sutil.", result: 3, feedback: 'bad', scores: { 'Comunicación': -15, 'Trabajo en Equipo': -5 } }
                ]
            },
            {
                id: 2, text: "La tensión en la reunión aumenta. Tu insistencia es vista como insubordinación.", options: [
                    { text: "Disculparte por tu insistencia y reenfocar la reunión en los temas originales.", result: 1, feedback: 'neutral', scores: { 'Comunicación': 5 } },
                    { text: "Abandonar la reunión frustrado.", result: 3, feedback: 'bad', scores: { 'Comunicación': -10, 'Trabajo en Equipo': -10 } }
                ]
            },
            { id: 3, text: "Lograste que tu idea fuera escuchada y valorada.", feedbackText: "Tu perseverancia y uso de datos para comunicar tu punto de vista fueron clave. No te rendiste, pero elegiste el momento y la forma adecuados.", options: [] }
        ]
    },
    {
        id: "escenario_6",
        area: "Transversal",
        title: "Compañero con Dificultades",
        description: "Un compañero de equipo está visiblemente estresado y su rendimiento ha bajado.",
        completed: false,
        totalSteps: 2,
        story: [
            {
                id: 0, text: "Notas que tu compañero, David, está cometiendo errores y parece agobiado. Esto está afectando al equipo. ¿Qué haces?", options: [
                    { text: "Acercarte a él en privado y preguntarle si todo está bien y si puedes ayudar.", result: 1, feedback: 'good', scores: { 'Trabajo en Equipo': 15, 'Comunicación': 10 } },
                    { text: "Informar al líder del equipo sobre el bajo rendimiento de David.", result: 2, feedback: 'neutral', scores: { 'Trabajo en Equipo': -5 } },
                    { text: "Ignorar la situación, esperando que se resuelva sola.", result: 2, feedback: 'bad', scores: { 'Trabajo en Equipo': -15, 'Liderazgo': -5 } }
                ]
            },
            {
                id: 1, text: "David te confiesa que tiene problemas personales. Te agradece tu preocupación. ¿Qué haces ahora?", options: [
                    { text: "Sugerirle hablar con el líder para buscar una solución temporal (reducir carga, etc.).", result: 3, feedback: 'good', scores: { 'Trabajo en Equipo': 10, 'Toma de Decisiones': 10 } },
                    { text: "Ofrecerte a hacer parte de su trabajo en secreto para cubrirlo.", result: 3, feedback: 'neutral', scores: { 'Trabajo en Equipo': 5, 'Toma de Decisiones': -10 } }
                ]
            },
            {
                id: 2, text: "El rendimiento de David sigue bajando, y ahora el equipo está resentido porque no se ha hecho nada al respecto.", options: [
                    { text: "Proponer una reunión de equipo para redistribuir tareas, sin señalar a David.", result: 1, feedback: 'good', scores: { 'Liderazgo': 10, 'Trabajo en Equipo': 5 } },
                    { text: "Quejarte con otros compañeros sobre la situación.", result: 3, feedback: 'bad', scores: { 'Trabajo en Equipo': -15 } }
                ]
            },
            { id: 3, text: "Has ayudado a tu compañero y al equipo.", feedbackText: "Mostraste una gran inteligencia emocional y empatía, fortaleciendo la confianza y el apoyo dentro del equipo.", options: [] }
        ]
    },
    {
        id: "escenario_7",
        area: "Transversal",
        title: "Prioridades del Proyecto",
        description: "Recibes dos tareas urgentes al mismo tiempo y debes decidir cuál abordar primero.",
        completed: false,
        totalSteps: 2,
        story: [
            {
                id: 0, text: "Tu líder te asigna una tarea urgente. Minutos después, el jefe de otro departamento te pide ayuda con algo que también es 'para ayer'. ¿Qué haces?", options: [
                    { text: "Preguntar a tu líder que te ayude a priorizar, explicándole la nueva solicitud.", result: 1, feedback: 'good', scores: { 'Comunicación': 15, 'Toma de Decisiones': 10 } },
                    { text: "Intentar hacer ambas a la vez, dividiendo tu atención.", result: 2, feedback: 'bad', scores: { 'Toma de Decisiones': -15 } },
                    { text: "Hacer primero la tarea que te pidió tu líder directo, ignorando la otra solicitud.", result: 2, feedback: 'neutral', scores: { 'Comunicación': -5, 'Trabajo en Equipo': -5 } }
                ]
            },
            {
                id: 1, text: "Tu líder revisa ambas tareas y te indica cuál tiene mayor impacto para la empresa. Te agradece haberlo consultado.", options: [
                    { text: "Agradecerle y comunicarle la decisión al otro jefe de departamento.", result: 3, feedback: 'good', scores: { 'Comunicación': 10, 'Trabajo en Equipo': 5 } },
                    { text: "Simplemente empezar a trabajar en la tarea priorizada.", result: 3, feedback: 'neutral', scores: { 'Comunicación': -5 } }
                ]
            },
            {
                id: 2, text: "Al intentar hacer todo, no terminas ninguna de las dos tareas a tiempo, lo que genera problemas en ambas áreas.", options: [
                    { text: "Asumir tu error, disculparte con ambos y presentar un plan para remediarlo.", result: 1, feedback: 'good', scores: { 'Liderazgo': 5, 'Comunicación': 10 } },
                    { text: "Justificarte diciendo que tenías demasiado trabajo.", result: 3, feedback: 'bad', scores: { 'Liderazgo': -10 } }
                ]
            },
            { id: 3, text: "Has gestionado las prioridades de forma profesional.", feedbackText: "Supiste cómo escalar una decisión y comunicarte efectivamente para manejar expectativas y cumplir con lo más importante.", options: [] }
        ]
    },
    {
        id: "escenario_8",
        area: "Transversal",
        title: "Presentación Inesperada",
        description: "A último minuto, te piden presentar el avance de un proyecto en lugar de tu líder.",
        completed: false,
        totalSteps: 2,
        story: [
            {
                id: 0, text: "Tu líder tiene una emergencia y te pide que presentes el avance del proyecto a los directivos en 15 minutos. No estás totalmente preparado.", options: [
                    { text: "Aceptar el reto, revisar rápidamente las notas clave y enfocarte en los puntos más importantes.", result: 1, feedback: 'good', scores: { 'Liderazgo': 10, 'Toma de Decisiones': 10 } },
                    { text: "Decir que no estás preparado y sugerir que se posponga la reunión.", result: 2, feedback: 'bad', scores: { 'Liderazgo': -10, 'Trabajo en Equipo': -5 } },
                    { text: "Aceptar, pero empezar la presentación pidiendo disculpas por no estar preparado.", result: 2, feedback: 'neutral', scores: { 'Comunicación': -5 } }
                ]
            },
            {
                id: 1, text: "La presentación es un éxito. Respondes las preguntas con confianza y los directivos quedan impresionados con tu proactividad.", options: [
                    { text: "Al final, dar crédito a tu líder y al equipo por el trabajo realizado.", result: 3, feedback: 'good', scores: { 'Liderazgo': 10, 'Trabajo en Equipo': 15 } },
                    { text: "Aceptar todos los elogios como si fueran solo tuyos.", result: 3, feedback: 'bad', scores: { 'Trabajo en Equipo': -15 } }
                ]
            },
            {
                id: 2, text: "Tu negativa o tu falta de confianza inicial genera una mala impresión y la reunión se cancela, afectando la percepción del equipo.", options: [
                    { text: "Hablar con tu líder después para explicarle tu inseguridad y prepararte mejor para el futuro.", result: 1, feedback: 'good', scores: { 'Comunicación': 10 } },
                    { text: "Evitar el tema y esperar que no vuelva a suceder.", result: 3, feedback: 'bad', scores: { 'Comunicación': -10 } }
                ]
            },
            { id: 3, text: "¡Oportunidad aprovechada!", feedbackText: "Demostraste liderazgo, confianza y lealtad a tu equipo. Convertiste un problema en una oportunidad para brillar.", options: [] }
        ]
    }
];
